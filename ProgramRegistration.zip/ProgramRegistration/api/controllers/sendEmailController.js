const nodemalier = require("nodemailer");

const nofityStudent=function (student, message){



}

module.exports={nofityStudent}

